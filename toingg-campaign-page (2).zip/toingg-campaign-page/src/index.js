const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3001;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '../public')));

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Example routes for API
app.get('/', (req, res) => {
  res.send('Root route is working!');
});

app.get('/api/languages', (req, res) => {
  console.log('GET /api/languages hit');
  res.json({ languages: ['English', 'Spanish', 'French'] });
});

app.get('/api/voices', (req, res) => {
  console.log('GET /api/voices hit');
  res.json({ voices: ['Voice 1', 'Voice 2', 'Voice 3'] });
});

app.post('/api/create-campaign', (req, res) => {
  console.log('POST /api/create-campaign hit');
  res.json({ message: 'Campaign created successfully!' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
